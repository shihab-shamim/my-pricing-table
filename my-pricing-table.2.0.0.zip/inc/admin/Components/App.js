import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import Welcome from '../../../../bpl-tools/Admin/Welcome';
import Demos from '../../../../bpl-tools/Admin/Demos';
import Pricing from '../../../../bpl-tools/Admin/Pricing';
import OurPlugins from '../../../../bpl-tools/Admin/OurPlugins';

import Layout from './Layout';
import { demoInfo, welcomeInfo } from '../utils/data';

const App = (props) => {
	const {  adminUrl } = props;

	return (
		<Router>
			<Routes>
				<Route path='/' element={<Layout {...props} />}>
					<Route index element={<Welcome {...props} {...welcomeInfo(adminUrl)} />} />
					<Route path='welcome' element={<Welcome {...props} {...welcomeInfo(adminUrl)} />} />
					<Route path='demos' element={<Demos {...props} demoInfo={demoInfo} />} />
					<Route path='our-plugins' element={<OurPlugins {...props} />} />
					<Route path='*' element={<Navigate to='/welcome' replace />} />
				</Route>
			</Routes>
		</Router>
	);
};

export default App;
