import Overview from '../../../../bpl-tools/Admin/Overview/Overview';
import Changelog from '../../../../bpl-tools/Admin/Changelog/Changelog';
// import FSCheckoutButton from '../../../../bpl-tools/Admin/FSCheckoutButton/FSCheckoutButton';
import { changelogs } from '../utils/data';
import { Button } from '../../../../bpl-tools/Components';

const Welcome = props => {
  const { isPremium, adminUrl } = props; //name,  freemius,

  return (
    <>
      <Overview {...props}>
        {!isPremium && (
          <Button href={`${adminUrl}edit.php?post_type=bppt-pricing-table&page=b-pricing-table-block#/pricing`} variant="secondary">
            Buy Now
          </Button>
        )}
        {/* {!isPremium &&
			// <FSCheckoutButton {...{
			// 	freemius,
			// 	options: { title: name },
			// 	buttonProps: { variant: 'secondary' }

			// }}>Buy Now
			// </FSCheckoutButton>
			} */}
      </Overview>

      <Changelog changelogs={changelogs} {...props} />
    </>
  );
};
export default Welcome;
