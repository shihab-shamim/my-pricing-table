import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
// import ListDemos from '../../../../bpl-tools/Admin/Demos/ListDemos';
import FilterDemos from '../../../../bpl-tools/Admin/Demos/FilterDemos'
import Pricing from '../../../../bpl-tools/Admin/Pricing/Pricing';
// import FSCheckoutButton from "../../../../bpl-tools/Admin/FSCheckoutButton/FSCheckoutButton";
// import FeatureCompare from '../../../../bpl-tools/Admin/FeatureCompare/FeatureCompare';

import Layout from './Layout';
import { pricingInfo,  filterDemoInfo } from '../utils/data'; //akne hobe featureCompareInfo jodi lage
import Welcome from './Welcome';
import { Button } from '../../../../bpl-tools/Components';

const App = (props) => {
	const { isPremium,  adminUrl } = props;

	return <Router>
		<Routes>
			<Route path='/' element={<Layout {...props} />}>
				<Route index element={<Welcome {...props} />} />

				<Route path='welcome' element={<Welcome {...props} />} />

				{/* <Route path='demos' element={<ListDemos demoInfo={demoInfo} {...props}>
					{!isPremium && <FSCheckoutButton {...{
						freemius,
						options: { title: name }
					}}>Buy Now</FSCheckoutButton>}
				</ListDemos>} /> */}

				<Route path='filter-demos' element={<FilterDemos demoInfo={filterDemoInfo}{...props}>
					{!isPremium && <Button href={`${adminUrl}edit.php?post_type=bppt-pricing-table&page=b-pricing-table-block#/pricing`} variant="secondary">
                 Buy Now
          </Button>}
				</FilterDemos>} />

				{!isPremium && <Route path='pricing' element={<>
					<Pricing pricingInfo={pricingInfo} options={{}} {...props}>
						<h2 style={{textAlign:'center', fontSize:'30px', fontWeight: "bold", marginBottom: '25px'}}>One-time payment, lifetime access</h2>
					</Pricing>
				</>} />}


				{/* {!isPremium && <Route path='feature-comparison' element={<FeatureCompare featureCompareInfo={featureCompareInfo} {...props} />} />} */}


				<Route path='*' element={<Navigate to='/welcome' replace />} />
			</Route>
		</Routes>
	</Router>
}
export default App;